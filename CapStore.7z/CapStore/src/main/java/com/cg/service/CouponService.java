package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;
import java.sql.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.beans.Coupon;
import com.cg.repo.CouponRepo;

@Component(value="CouponService")
public class CouponService {
	@Autowired
	private CouponRepo couponRepo;

	public int addcoupon(Coupon coupon) {
		/*String[] string= {"FIRST","CPST","FEST"};
		Random random=new Random();
		int index=random.nextInt(3);
		int i=(int)(Math.random()*1000);
		System.out.println(string[index]+i);*/
		couponRepo.save(coupon);
		return coupon.getCouponId();
	}
	
	public List<Coupon> displayAllcoupons() {
		return couponRepo.findAll();
	}
	public void deleteCoupon(int couponId) {
		couponRepo.deleteById(couponId);	
	}
	public void applyCoupon( int orderid,String CouponName) {
		Coupon Coupon = couponRepo.findByCouponName(CouponName);
		//OrderDetails order= orderDetailsRepo.getOrderDetails(orderid);
		if(Coupon!=null)
		{
			LocalDate localdate = LocalDate.now();
			Date date1= Date.valueOf(localdate);
			/*if(Coupon.getStartDate().before(date1)&&Coupon.getEndDate().after(date1)&&order.getOrderAmount()>Coupon.getCouponQuantity())
			{
				//order.setOrderAmount(order.getOrderAmount()-Coupon.getCouponQuantity());
				//orderDetailsRepo.save(order);
			}*/
		}
	}
}
