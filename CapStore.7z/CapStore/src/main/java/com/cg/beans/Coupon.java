package com.cg.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Coupon")
public class Coupon {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int couponId;
	private String couponType;
	private String couponName;
	private String couponDescripton;
	private int couponQuantity;
	private Date startDate;
	private Date endDate;

	//Constructors
	public Coupon() {
		super();
	}
	
	public Coupon(int couponId) {
		super();
		this.couponId = couponId;
	}


	public Coupon(int couponId, String couponType, String couponName, String couponDescription) {
		super();
		this.couponId = couponId;
		this.couponType = couponType;
		this.couponName = couponName;
		this.couponDescripton = couponDescription;
	}
	
	
	//Getters and Setters
	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public String getCouponDescripton() {
		return couponDescripton;
	}

	public void setCouponDescripton(String couponDescripton) {
		this.couponDescripton = couponDescripton;
	}

	public int getCouponQuantity() {
		return couponQuantity;
	}

	public void setCouponQuantity(int couponQuantity) {
		this.couponQuantity = couponQuantity;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	
}
