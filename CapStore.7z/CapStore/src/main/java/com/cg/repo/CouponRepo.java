package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cg.beans.Coupon;

public interface CouponRepo extends JpaRepository<Coupon, Integer>, CrudRepository<Coupon, Integer> {
	    
	@Query("SELECT c FROM Coupon c WHERE c.couponName=?1")
		public Coupon findByCouponName(String CouponName);

}
